﻿using UnityEngine;

namespace BehaviourTree
{
    public class CheckHealthNode : Node
    {
        private int _health;

        public CheckHealthNode(int health)
        {
            _health = health;
        }
        
        public override NodeState Evaluate()
        {
            if (_health <= 0)
            {
                Debug.Log("NPC is Dead");
                State = NodeState.Success;
            }
            else
            {
                State = NodeState.Failure;
            }
            return State;
        }

    }
}