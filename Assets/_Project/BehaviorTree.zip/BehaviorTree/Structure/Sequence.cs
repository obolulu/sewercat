﻿using System.Collections.Generic;

namespace BehaviourTree.Structure
{
    public class Sequence : Node
    {
        private List<Node> _children = new List<Node>();
        
        public Sequence(List<Node> children)
        {
            _children = children;
        }

        public override NodeState Evaluate()
        {
            foreach (var child in _children)
            {
                switch (child.Evaluate())
                {
                    case NodeState.Failure:
                        State = NodeState.Failure;
                        return State;
                    case NodeState.Running:
                        State = NodeState.Running;
                        return State;
                }
            }
            State = NodeState.Success;
            return State;
        }
    }
}