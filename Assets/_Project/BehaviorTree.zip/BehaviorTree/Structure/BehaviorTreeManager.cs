﻿using UnityEngine;

namespace BehaviourTree.Structure
{
    public class BehaviorTreeManager : MonoBehaviour
    {
        private Node _rootNode;
    }
}