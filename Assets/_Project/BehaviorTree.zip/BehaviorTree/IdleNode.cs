﻿using UnityEngine;

namespace BehaviourTree
{
    public class IdleNode : Node
    {
        public override NodeState Evaluate()
        {
            Debug.Log("Enemy is Idling");
            State = NodeState.Success;
            return State;
        }
    }
}